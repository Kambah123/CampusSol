// Campus SOL Starter - Leaderboard Page

import { useState, useEffect } from 'react';
import { 
  Section, 
  Title,
  Text,
  Avatar,
  Badge
} from '@telegram-apps/telegram-ui';
import { Trophy, Medal, Award, Users, TrendingUp, Zap } from 'lucide-react';
import type { LeaderboardEntry } from '@/types';
import { getLeaderboard } from '@/hooks/useUserProgress';

export const LeaderboardPage = () => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'quests' | 'rewards' | 'badges'>('quests');

  useEffect(() => {
    const data = getLeaderboard();
    setLeaderboard(data);
  }, []);

  const getSortedData = () => {
    switch (activeTab) {
      case 'rewards':
        return [...leaderboard].sort((a, b) => b.totalRewards - a.totalRewards);
      case 'badges':
        return leaderboard.filter(u => u.badgeMinted);
      default:
        return [...leaderboard].sort((a, b) => b.questsCompleted - a.questsCompleted);
    }
  };

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 0:
        return (
          <div className="rank-badge gold">
            <Trophy className="w-4 h-4" />
          </div>
        );
      case 1:
        return (
          <div className="rank-badge silver">
            <Medal className="w-4 h-4" />
          </div>
        );
      case 2:
        return (
          <div className="rank-badge bronze">
            <Award className="w-4 h-4" />
          </div>
        );
      default:
        return (
          <div className="rank-badge normal">
            {rank + 1}
          </div>
        );
    }
  };

  const data = getSortedData();
  const totalStudents = leaderboard.length;
  const totalDistributed = leaderboard.reduce((sum, u) => sum + u.totalRewards, 0);
  const badgeHolders = leaderboard.filter(u => u.badgeMinted).length;

  return (
    <div className="animate-slide-up">
      {/* Header */}
      <Section className="p-4 pt-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center">
            <Trophy className="w-6 h-6 text-black" />
          </div>
          <div>
            <Title level="1" className="text-white m-0">Leaderboard</Title>
            <Text className="text-gray-400">Top Campus SOL Pioneers</Text>
          </div>
        </div>
      </Section>

      {/* Stats */}
      <Section className="px-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="stat-card p-3 text-center">
            <Users className="w-5 h-5 text-purple-400 mx-auto mb-1" />
            <Text className="text-xl font-bold text-white">{totalStudents}</Text>
            <Text className="text-gray-500 text-xs">Students</Text>
          </div>
          <div className="stat-card p-3 text-center">
            <Zap className="w-5 h-5 text-green-400 mx-auto mb-1" />
            <Text className="text-xl font-bold text-white">{totalDistributed.toFixed(2)}</Text>
            <Text className="text-gray-500 text-xs">SOL</Text>
          </div>
          <div className="stat-card p-3 text-center">
            <Award className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
            <Text className="text-xl font-bold text-white">{badgeHolders}</Text>
            <Text className="text-gray-500 text-xs">Badges</Text>
          </div>
        </div>
      </Section>

      {/* Custom Tabs */}
      <Section className="px-4 py-2">
        <div className="flex gap-2 p-1 bg-gray-800/50 rounded-xl">
          {(['quests', 'rewards', 'badges'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 flex items-center justify-center gap-1 py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab
                  ? 'bg-purple-500/20 text-purple-400'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              {tab === 'quests' && <TrendingUp className="w-4 h-4" />}
              {tab === 'rewards' && <Zap className="w-4 h-4" />}
              {tab === 'badges' && <Award className="w-4 h-4" />}
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </Section>

      {/* Leaderboard List */}
      <Section className="px-4 pb-24">
        {data.length === 0 ? (
          <div className="text-center py-12">
            <Trophy className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <Text className="text-gray-400">No entries yet</Text>
            <Text className="text-gray-500 text-sm">Be the first to complete quests!</Text>
          </div>
        ) : (
          <div className="space-y-2">
            {data.slice(0, 20).map((entry, index) => (
              <div
                key={entry.userId}
                className={`leaderboard-item ${index < 3 ? `top-${index + 1}` : ''}`}
              >
                {getRankBadge(index)}
                
                <Avatar 
                  src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${entry.userId}`}
                  size={40}
                  className="flex-shrink-0"
                />
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Text className="text-white font-medium truncate">
                      {entry.firstName || entry.username || 'Anonymous'}
                    </Text>
                    {entry.badgeMinted && (
                      <Award className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                    )}
                  </div>
                  <Text className="text-gray-500 text-sm">
                    {activeTab === 'rewards' 
                      ? `${entry.totalRewards.toFixed(4)} SOL earned`
                      : `${entry.questsCompleted} quests completed`
                    }
                  </Text>
                </div>
                
                <div className="text-right">
                  {activeTab === 'quests' && (
                    <Badge type="number" className="badge-pill sol">
                      {entry.questsCompleted}
                    </Badge>
                  )}
                  {activeTab === 'rewards' && (
                    <Badge type="number" className="badge-pill sol">
                      {entry.totalRewards.toFixed(3)}
                    </Badge>
                  )}
                  {activeTab === 'badges' && (
                    <Badge type="number" className="badge-pill completed">
                      Certified
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Section>
    </div>
  );
};
